package com.cc.iosconnect;

import android.app.UiModeManager;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.database.ContentObserver;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.location.LocationManager;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.os.UserHandle;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.view.MotionEvent;
import android.view.View;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.robv.android.xposed.XposedBridge;

/**
 * Ek gol tile. Look neeche wale stock tiles jaisa: ON = safed gol + neela icon,
 * OFF = grey gol + safed icon. Icons Material (24x24) vector paths se draw hote hain.
 */
public class TileView extends View {
    public static final int DATA = 0, WIFI = 1, HOTSPOT = 2, BT = 3, FLASH = 4,
            AIRPLANE = 5, DND = 6, SILENT = 7, LOCATION = 8, DARK = 9;
    public static final int COUNT = 10;

    public static final String[] LABELS = {
            "Data", "Wi-Fi", "Hotspot", "Bluetooth", "Torch",
            "Airplane", "DND", "Silent", "Location", "Dark"};

    // ---- Rang yahan badlo (stock tiles jaise) ----
    static final int ON_BG = 0xFFF4F5F7;     // active: safed gol
    static final int ON_ICON = 0xFF4285F4;   // active: neela icon
    static final int OFF_BG = 0xB35A5E63;    // inactive: grey gol
    static final int OFF_ICON = 0xFFFFFFFF;  // inactive: safed icon

    // ---- Material icon paths (viewBox 24x24) ----
    private static final String[] PATH_DATA = {
            // DATA (swap_vert)
            "M16,17.01V10h-2v7.01h-3L15,21l4,-3.99h-3zM9,3L5,6.99h3V14h2V6.99h3L9,3z",
            // WIFI
            "M1,9l2,2c4.97,-4.97 13.03,-4.97 18,0l2,-2C16.93,2.93 7.08,2.93 1,9zM9,17l3,3 3,-3c-1.65,-1.66 -4.34,-1.66 -6,0zM5,13l2,2c2.76,-2.76 7.24,-2.76 10,0l2,-2C15.14,9.14 8.87,9.14 5,13z",
            // HOTSPOT (wifi_tethering)
            "M12,11c-1.1,0 -2,0.9 -2,2s0.9,2 2,2 2,-0.9 2,-2 -0.9,-2 -2,-2zM18,13c0,-3.31 -2.69,-6 -6,-6s-6,2.69 -6,6c0,2.22 1.21,4.15 3,5.19l1,-1.74c-1.19,-0.7 -2,-1.97 -2,-3.45 0,-2.21 1.79,-4 4,-4s4,1.79 4,4c0,1.48 -0.81,2.75 -2,3.45l1,1.74c1.79,-1.04 3,-2.97 3,-5.19zM12,3C6.48,3 2,7.48 2,13c0,3.7 2.01,6.92 4.99,8.65l1,-1.73C5.61,18.53 4,15.96 4,13c0,-4.42 3.58,-8 8,-8s8,3.58 8,8c0,2.96 -1.61,5.53 -4,6.92l1,1.73c2.99,-1.73 5,-4.95 5,-8.65 0,-5.52 -4.48,-10 -10,-10z",
            // BT
            "M17.71,7.71L12,2h-1v7.59L6.41,5 5,6.41 10.59,12 5,17.59 6.41,19 11,14.41V22h1l5.71,-5.71 -4.3,-4.29 4.3,-4.29zM13,5.83l1.88,1.88L13,9.59V5.83zM14.88,16.29L13,18.17v-3.76l1.88,1.88z",
            // FLASH (torch)
            "M7,2h10v5l-2,3v12H9V10L7,7V2z M11,12h2v3h-2z",
            // AIRPLANE
            "M21,16v-2l-8,-5V3.5c0,-0.83 -0.67,-1.5 -1.5,-1.5S10,2.67 10,3.5V9l-8,5v2l8,-2.5V19l-2,1.5V22l3.5,-1 3.5,1v-1.5L13,19v-5.5l8,2.5z",
            // DND (minus in circle)
            "M12,2C6.48,2 2,6.48 2,12s4.48,10 10,10 10,-4.48 10,-10S17.52,2 12,2zM17,13H7v-2h10v2z",
            // SILENT (bell; upar se slash alag draw hota hai)
            "M12,22c1.1,0 2,-0.9 2,-2h-4c0,1.1 0.9,2 2,2z M18,16v-5c0,-3.07 -1.63,-5.64 -4.5,-6.32V4c0,-0.83 -0.67,-1.5 -1.5,-1.5s-1.5,0.67 -1.5,1.5v0.68C7.64,5.36 6,7.92 6,11v5l-2,2v1h16v-1l-2,-2z",
            // LOCATION
            "M12,2C8.13,2 5,5.13 5,9c0,5.25 7,13 7,13s7,-7.75 7,-13c0,-3.87 -3.13,-7 -7,-7zM12,11.5c-1.38,0 -2.5,-1.12 -2.5,-2.5s1.12,-2.5 2.5,-2.5 2.5,1.12 2.5,2.5 -1.12,2.5 -2.5,2.5z",
            // DARK (moon)
            "M12,3c-4.97,0 -9,4.03 -9,9s4.03,9 9,9 9,-4.03 9,-9c0,-0.46 -0.04,-0.92 -0.1,-1.36 -0.98,1.37 -2.58,2.26 -4.4,2.26 -2.98,0 -5.4,-2.42 -5.4,-5.4 0,-1.81 0.89,-3.42 2.26,-4.4C12.92,3.04 12.46,3 12,3z"
    };
    private static Path[] PATHS;

    private static synchronized Path[] paths() {
        if (PATHS == null) {
            Path[] p = new Path[PATH_DATA.length];
            for (int i = 0; i < p.length; i++) p[i] = parsePath(PATH_DATA[i]);
            PATHS = p;
        }
        return PATHS;
    }

    // ---- chhota SVG path parser: M m L l H h V v C c S s Z z ----
    private static final Pattern TOKEN = Pattern.compile(
            "[MmLlHhVvCcSsZz]|-?(?:\\d+\\.?\\d*|\\.\\d+)(?:[eE][-+]?\\d+)?");

    private static float num(List<String> t, int i) {
        return i < t.size() ? Float.parseFloat(t.get(i)) : 0f;
    }

    static Path parsePath(String d) {
        Path p = new Path();
        p.setFillType(Path.FillType.EVEN_ODD);
        List<String> t = new ArrayList<>();
        Matcher m = TOKEN.matcher(d);
        while (m.find()) t.add(m.group());
        int i = 0;
        char cmd = ' ';
        float cx = 0, cy = 0, sx = 0, sy = 0, lx = 0, ly = 0;
        boolean lastCubic = false;
        while (i < t.size()) {
            String s = t.get(i);
            if (Character.isLetter(s.charAt(0))) {
                cmd = s.charAt(0);
                i++;
                if (cmd == 'Z' || cmd == 'z') { p.close(); cx = sx; cy = sy; lastCubic = false; }
                continue;
            }
            switch (cmd) {
                case 'M': case 'm': {
                    float x = num(t, i++), y = num(t, i++);
                    if (cmd == 'm') { x += cx; y += cy; }
                    p.moveTo(x, y); cx = sx = x; cy = sy = y; lastCubic = false;
                    cmd = (cmd == 'm') ? 'l' : 'L';
                    break;
                }
                case 'L': case 'l': {
                    float x = num(t, i++), y = num(t, i++);
                    if (cmd == 'l') { x += cx; y += cy; }
                    p.lineTo(x, y); cx = x; cy = y; lastCubic = false;
                    break;
                }
                case 'H': case 'h': {
                    float x = num(t, i++);
                    if (cmd == 'h') x += cx;
                    p.lineTo(x, cy); cx = x; lastCubic = false;
                    break;
                }
                case 'V': case 'v': {
                    float y = num(t, i++);
                    if (cmd == 'v') y += cy;
                    p.lineTo(cx, y); cy = y; lastCubic = false;
                    break;
                }
                case 'C': case 'c': {
                    float x1 = num(t, i++), y1 = num(t, i++), x2 = num(t, i++), y2 = num(t, i++),
                            x = num(t, i++), y = num(t, i++);
                    if (cmd == 'c') { x1 += cx; y1 += cy; x2 += cx; y2 += cy; x += cx; y += cy; }
                    p.cubicTo(x1, y1, x2, y2, x, y);
                    lx = x2; ly = y2; cx = x; cy = y; lastCubic = true;
                    break;
                }
                case 'S': case 's': {
                    float x2 = num(t, i++), y2 = num(t, i++), x = num(t, i++), y = num(t, i++);
                    if (cmd == 's') { x2 += cx; y2 += cy; x += cx; y += cy; }
                    float x1 = lastCubic ? 2 * cx - lx : cx;
                    float y1 = lastCubic ? 2 * cy - ly : cy;
                    p.cubicTo(x1, y1, x2, y2, x, y);
                    lx = x2; ly = y2; cx = x; cy = y; lastCubic = true;
                    break;
                }
                default:
                    i++;
            }
        }
        return p;
    }

    // ------------------------------------------------------------ fields
    private int kind;
    private final boolean interactive;
    private boolean active;
    private boolean torchOn;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Handler main = new Handler(Looper.getMainLooper());
    private CameraManager.TorchCallback torchCb;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { refresh(); }
    };
    private final ContentObserver observer = new ContentObserver(main) {
        @Override public void onChange(boolean selfChange) { refresh(); }
    };

    public TileView(Context c, int kind) { this(c, kind, true); }

    /** interactive=false: sirf picker me preview ke liye (toggle/state nahi). */
    public TileView(Context c, int kind, boolean interactive) {
        super(c);
        this.kind = kind;
        this.interactive = interactive;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        fill.setStyle(Paint.Style.FILL);
        if (interactive) {
            setClickable(true);
            setOnClickListener(v -> toggle());
            setOnLongClickListener(v -> { openSettings(); return true; });
        }
    }

    public void setKind(int k) { kind = k; invalidate(); }

    // ------------------------------------------------------------ state
    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (!interactive) return;
        Context c = getContext();
        IntentFilter f = new IntentFilter();
        f.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        f.addAction("android.net.wifi.WIFI_AP_STATE_CHANGED");
        f.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        f.addAction(AudioManager.RINGER_MODE_CHANGED_ACTION);
        f.addAction("android.location.MODE_CHANGED");
        f.addAction("android.intent.action.AIRPLANE_MODE");
        try { c.registerReceiver(receiver, f); } catch (Throwable ignored) { }
        try {
            c.getContentResolver().registerContentObserver(Settings.Global.CONTENT_URI, true, observer);
        } catch (Throwable ignored) { }
        if (kind == FLASH) {
            try {
                CameraManager cm = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
                torchCb = new CameraManager.TorchCallback() {
                    @Override public void onTorchModeChanged(String id, boolean enabled) {
                        torchOn = enabled; refresh();
                    }
                };
                cm.registerTorchCallback(torchCb, main);
            } catch (Throwable t) {
                XposedBridge.log("IOSConnect: torch callback fail: " + t);
            }
        }
        refresh();
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (!interactive) return;
        Context c = getContext();
        try { c.unregisterReceiver(receiver); } catch (Throwable ignored) { }
        try { c.getContentResolver().unregisterContentObserver(observer); } catch (Throwable ignored) { }
        if (torchCb != null) {
            try {
                ((CameraManager) c.getSystemService(Context.CAMERA_SERVICE)).unregisterTorchCallback(torchCb);
            } catch (Throwable ignored) { }
            torchCb = null;
        }
    }

    @Override protected void onConfigurationChanged(Configuration n) {
        super.onConfigurationChanged(n);
        if (interactive) refresh();
    }

    private void refresh() {
        boolean s = false;
        try {
            Context c = getContext();
            switch (kind) {
                case WIFI:
                    s = ((WifiManager) c.getSystemService(Context.WIFI_SERVICE)).isWifiEnabled();
                    break;
                case BT:
                    BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter();
                    s = a != null && a.isEnabled();
                    break;
                case DATA:
                    s = c.getSystemService(TelephonyManager.class).isDataEnabled();
                    break;
                case HOTSPOT:
                    s = isHotspotOn();
                    break;
                case FLASH:
                    s = torchOn;
                    break;
                case AIRPLANE:
                    s = Settings.Global.getInt(c.getContentResolver(), "airplane_mode_on", 0) == 1;
                    break;
                case DND:
                    s = Settings.Global.getInt(c.getContentResolver(), "zen_mode", 0) != 0;
                    break;
                case SILENT:
                    s = ((AudioManager) c.getSystemService(Context.AUDIO_SERVICE)).getRingerMode()
                            != AudioManager.RINGER_MODE_NORMAL;
                    break;
                case LOCATION:
                    s = c.getSystemService(LocationManager.class).isLocationEnabled();
                    break;
                case DARK:
                    s = (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                            == Configuration.UI_MODE_NIGHT_YES;
                    break;
            }
        } catch (Throwable t) {
            XposedBridge.log("IOSConnect: refresh " + kind + ": " + t);
        }
        if (s != active) { active = s; invalidate(); }
    }

    private boolean isHotspotOn() {
        try {
            WifiManager wm = (WifiManager) getContext().getSystemService(Context.WIFI_SERVICE);
            Method m = WifiManager.class.getMethod("isWifiApEnabled");
            return (Boolean) m.invoke(wm);
        } catch (Throwable t) { return false; }
    }

    // ------------------------------------------------------------ actions
    @SuppressWarnings("deprecation")
    private void toggle() {
        Context c = getContext();
        boolean target = !active;
        try {
            switch (kind) {
                case WIFI:
                    ((WifiManager) c.getSystemService(Context.WIFI_SERVICE)).setWifiEnabled(target);
                    break;
                case BT:
                    BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter();
                    if (a != null) { if (target) a.enable(); else a.disable(); }
                    break;
                case DATA:
                    c.getSystemService(TelephonyManager.class).setDataEnabled(target);
                    break;
                case HOTSPOT:
                    setHotspot(target);
                    break;
                case FLASH:
                    setTorch(target);
                    break;
                case AIRPLANE:
                    ConnectivityManager.class.getMethod("setAirplaneMode", boolean.class)
                            .invoke(c.getSystemService(ConnectivityManager.class), target);
                    break;
                case DND:
                    Settings.Global.putInt(c.getContentResolver(), "zen_mode", target ? 1 : 0);
                    break;
                case SILENT:
                    ((AudioManager) c.getSystemService(Context.AUDIO_SERVICE)).setRingerMode(
                            target ? AudioManager.RINGER_MODE_SILENT : AudioManager.RINGER_MODE_NORMAL);
                    break;
                case LOCATION:
                    LocationManager.class.getMethod("setLocationEnabledForUser", boolean.class, UserHandle.class)
                            .invoke(c.getSystemService(LocationManager.class), target, Process.myUserHandle());
                    break;
                case DARK:
                    c.getSystemService(UiModeManager.class).setNightModeActivated(target);
                    break;
            }
            active = target;       // foran feedback; asal state receiver se sync hogi
            invalidate();
            main.postDelayed(this::refresh, 1500);
        } catch (Throwable t) {
            XposedBridge.log("IOSConnect: toggle " + kind + " fail: " + t);
            openSettings();
        }
    }

    private void setTorch(boolean on) throws Exception {
        CameraManager cm = (CameraManager) getContext().getSystemService(Context.CAMERA_SERVICE);
        for (String id : cm.getCameraIdList()) {
            CameraCharacteristics ch = cm.getCameraCharacteristics(id);
            Boolean flash = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
            Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
            if (flash != null && flash && facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                cm.setTorchMode(id, on);
                return;
            }
        }
        throw new IllegalStateException("flash wala camera nahi mila");
    }

    private void setHotspot(boolean on) throws Exception {
        Context c = getContext();
        Object tm = c.getSystemService("tethering");           // android.net.TetheringManager
        if (on) {
            Class<?> cbType = Class.forName("android.net.TetheringManager$StartTetheringCallback",
                    false, tm.getClass().getClassLoader());
            Object cb = Proxy.newProxyInstance(cbType.getClassLoader(), new Class<?>[]{cbType},
                    new InvocationHandler() {
                        @Override public Object invoke(Object p, Method m, Object[] a) {
                            switch (m.getName()) {
                                case "hashCode": return System.identityHashCode(p);
                                case "equals": return p == a[0];
                                case "toString": return "HotspotCb";
                                default: return null;
                            }
                        }
                    });
            Method m = tm.getClass().getMethod("startTethering", int.class, Executor.class, cbType);
            m.invoke(tm, 0 /* TETHERING_WIFI */, c.getMainExecutor(), cb);
        } else {
            tm.getClass().getMethod("stopTethering", int.class).invoke(tm, 0);
        }
    }

    private void openSettings() {
        try {
            Intent i;
            switch (kind) {
                case WIFI: i = new Intent(Settings.ACTION_WIFI_SETTINGS); break;
                case BT: i = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS); break;
                case DATA: i = new Intent(Settings.ACTION_DATA_ROAMING_SETTINGS); break;
                case AIRPLANE: i = new Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS); break;
                case DND: i = new Intent("android.settings.ZEN_MODE_SETTINGS"); break;
                case SILENT: i = new Intent(Settings.ACTION_SOUND_SETTINGS); break;
                case LOCATION: i = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS); break;
                case DARK: i = new Intent(Settings.ACTION_DISPLAY_SETTINGS); break;
                case FLASH: return;
                default:
                    i = new Intent().setClassName("com.android.settings",
                            "com.android.settings.Settings$TetherSettingsActivity");
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        } catch (Throwable t) {
            XposedBridge.log("IOSConnect: openSettings fail: " + t);
        }
    }

    // ------------------------------------------------------------ touch feedback
    @Override public boolean onTouchEvent(MotionEvent e) {
        if (interactive) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).start(); break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL: animate().scaleX(1f).scaleY(1f).setDuration(120).start(); break;
            }
        }
        return super.onTouchEvent(e);
    }

    // ------------------------------------------------------------ drawing
    @Override protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h / 2f, r = Math.min(w, h) / 2f;
        fill.setColor(active ? ON_BG : OFF_BG);
        cv.drawCircle(cx, cy, r, fill);

        int ic = active ? ON_ICON : OFF_ICON;
        fill.setColor(ic);
        float sc = (r * 1.12f) / 24f;            // icon ~ gol ka 56%
        cv.save();
        cv.translate(cx - 12f * sc, cy - 12f * sc);
        cv.scale(sc, sc);
        cv.drawPath(paths()[kind], fill);
        if (kind == SILENT) {                     // slash (bell ke upar kat)
            stroke.setStrokeCap(Paint.Cap.ROUND);
            stroke.setColor(active ? ON_BG : 0xFF5A5E63);
            stroke.setStrokeWidth(4.2f);
            cv.drawLine(4.5f, 3.5f, 19.5f, 20.5f, stroke);
            stroke.setColor(ic);
            stroke.setStrokeWidth(2f);
            cv.drawLine(4.5f, 3.5f, 19.5f, 20.5f, stroke);
        }
        cv.restore();
    }
}
