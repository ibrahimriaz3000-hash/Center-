package com.cc.iosconnect;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

/**
 * Edit popup: upar 4 slots, neeche saare tiles. Slot chuno -> tile tap karo.
 * Ek tile do slots me nahi ho sakta (swap ho jata hai), isliye cluster me double nahi aata.
 */
final class Picker {
    private final ClusterView cluster;
    private final Context c;
    private final float d;
    private final int[] kinds;
    private final TileView[] slots = new TileView[4];
    private final Runnable stock;
    private int sel = 0;
    private PopupWindow pw;

    private Picker(ClusterView cl, Runnable stock) {
        this.cluster = cl;
        this.c = cl.getContext();
        this.d = c.getResources().getDisplayMetrics().density;
        this.kinds = Store.load(c);
        this.stock = stock;
    }

    /** stock = asli (stock) Edit screen kholne wala action; long-press se aaye to null. */
    static void show(ClusterView cl, Runnable stock) {
        try {
            if (cl.popup != null && cl.popup.isShowing()) return;
            new Picker(cl, stock).build();
        } catch (Throwable t) {
            de.robv.android.xposed.XposedBridge.log("IOSConnect: picker fail: " + t);
        }
    }

    private int dp(float v) { return Math.round(v * d); }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView pill(String s, int bg, final Runnable r) {
        TextView t = text(s, 14, 0xFFFFFFFF, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(9), dp(14), dp(9));
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(dp(20));
        t.setBackground(g);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private void build() {
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(16));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF2262A2E);
        bg.setCornerRadius(dp(28));
        bg.setStroke(Math.max(1, (int) d), 0x44FFFFFF);
        root.setBackground(bg);

        root.addView(text("Cluster ke tiles", 17, 0xFFFFFFFF, true));
        TextView hint = text("Pehle slot chuno, phir neeche se tile tap karo", 12, 0xAAFFFFFF, false);
        hint.setPadding(0, dp(2), 0, dp(10));
        root.addView(hint);

        // ---- 4 slots
        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER);
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            TileView t = new TileView(c, kinds[i], false);
            t.setOnClickListener(v -> { sel = idx; highlight(); });
            slots[i] = t;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(58), dp(58));
            lp.setMargins(dp(7), 0, dp(7), 0);
            row.addView(t, lp);
        }
        root.addView(row);

        View sp = new View(c);
        root.addView(sp, new LinearLayout.LayoutParams(1, dp(14)));

        // ---- saare tiles (4 per row)
        for (int k = 0; k < TileView.COUNT; k += 4) {
            LinearLayout r = new LinearLayout(c);
            for (int j = 0; j < 4; j++) {
                final int kind = k + j;
                LinearLayout cell = new LinearLayout(c);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                cell.setPadding(0, 0, 0, dp(8));
                if (kind < TileView.COUNT) {
                    TileView t = new TileView(c, kind, false);
                    t.setOnClickListener(v -> assign(kind));
                    cell.addView(t, new LinearLayout.LayoutParams(dp(52), dp(52)));
                    TextView lb = text(TileView.LABELS[kind], 10, 0xCCFFFFFF, false);
                    lb.setGravity(Gravity.CENTER);
                    lb.setSingleLine(true);
                    cell.addView(lb);
                }
                r.addView(cell, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            }
            root.addView(r);
        }

        // ---- buttons
        LinearLayout btns = new LinearLayout(c);
        btns.setGravity(Gravity.END);
        btns.setPadding(0, dp(6), 0, 0);
        if (stock != null) {
            btns.addView(pill("Stock Edit", 0x44FFFFFF, () -> { pw.dismiss(); stock.run(); }));
            btns.addView(new View(c), new LinearLayout.LayoutParams(dp(8), 1));
        }
        btns.addView(pill("Reset", 0x44FFFFFF, () -> {
            int[] df = Store.defaults();
            System.arraycopy(df, 0, kinds, 0, 4);
            apply();
        }));
        btns.addView(new View(c), new LinearLayout.LayoutParams(dp(8), 1));
        btns.addView(pill("Done", 0xFF4285F4, () -> pw.dismiss()));
        root.addView(btns);

        int sw = c.getResources().getDisplayMetrics().widthPixels;
        int w = Math.min(sw - dp(32), dp(360));
        pw = new PopupWindow(root, w, ViewGroup.LayoutParams.WRAP_CONTENT, true);
        pw.setBackgroundDrawable(new ColorDrawable(0));
        pw.setOutsideTouchable(true);
        pw.setElevation(dp(12));
        cluster.popup = pw;
        highlight();
        pw.showAtLocation(cluster, Gravity.CENTER, 0, 0);
    }

    private void assign(int kind) {
        for (int i = 0; i < 4; i++) {
            if (kinds[i] == kind && i != sel) { kinds[i] = kinds[sel]; break; }   // swap, double nahi
        }
        kinds[sel] = kind;
        apply();
        sel = (sel + 1) % 4;
        highlight();
    }

    private void apply() {
        Store.save(c, kinds);
        cluster.setKinds(kinds);
        for (int i = 0; i < 4; i++) slots[i].setKind(kinds[i]);
        highlight();
    }

    private void highlight() {
        for (int i = 0; i < 4; i++) {
            slots[i].setAlpha(i == sel ? 1f : 0.4f);
            slots[i].setScaleX(i == sel ? 1.1f : 1f);
            slots[i].setScaleY(i == sel ? 1.1f : 1f);
        }
    }
}
