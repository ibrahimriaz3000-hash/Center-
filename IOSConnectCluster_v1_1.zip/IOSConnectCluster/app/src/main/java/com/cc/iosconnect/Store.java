package com.cc.iosconnect;

import android.content.Context;
import android.provider.Settings;

import de.robv.android.xposed.XposedBridge;

/** Cluster ke 4 tiles ki list yaad rakhta hai (Settings.Secure me CSV, jaise "0,1,2,3"). */
final class Store {
    static final String KEY = "iosconnect_tiles";
    private static int[] cache;

    static int[] defaults() { return new int[]{TileView.DATA, TileView.WIFI, TileView.HOTSPOT, TileView.BT}; }

    static int[] load(Context c) {
        try {
            String s = Settings.Secure.getString(c.getContentResolver(), KEY);
            int[] k = parse(s);
            if (k != null) { cache = k; return k.clone(); }
        } catch (Throwable ignored) { }
        return cache != null ? cache.clone() : defaults();
    }

    static void save(Context c, int[] k) {
        cache = k.clone();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < k.length; i++) { if (i > 0) sb.append(','); sb.append(k[i]); }
        try {
            Settings.Secure.putString(c.getContentResolver(), KEY, sb.toString());
        } catch (Throwable t) {
            XposedBridge.log("IOSConnect: save fail (sirf memory me rakha): " + t);
        }
    }

    private static int[] parse(String s) {
        if (s == null) return null;
        String[] p = s.split(",");
        if (p.length != 4) return null;
        int[] k = new int[4];
        try {
            for (int i = 0; i < 4; i++) {
                k[i] = Integer.parseInt(p[i].trim());
                if (k[i] < 0 || k[i] >= TileView.COUNT) return null;
                for (int j = 0; j < i; j++) if (k[j] == k[i]) return null;   // duplicate nahi
            }
        } catch (NumberFormatException e) { return null; }
        return k;
    }
}
