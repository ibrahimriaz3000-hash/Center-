package com.cc.iosconnect;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;

/** 2x2 grid. Kaunse 4 tiles hon, ye Store se aata hai; Edit button / long-press se badalte hain. */
public class ClusterView extends ViewGroup {
    static ClusterView current;
    PopupWindow popup;
    private TileView[] tiles = new TileView[0];

    public ClusterView(Context c) {
        super(c);
        setClipChildren(false);
        setKinds(Store.load(c));
        setOnLongClickListener(v -> { Picker.show(this, null); return true; });
    }

    /** Tiles dobara banata hai (picker se live call hota hai). */
    public void setKinds(int[] kinds) {
        removeAllViews();
        tiles = new TileView[kinds.length];
        for (int i = 0; i < kinds.length; i++) {
            tiles[i] = new TileView(getContext(), kinds[i]);
            addView(tiles[i]);
        }
        requestLayout();
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        current = this;
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (current == this) current = null;
        if (popup != null) { try { popup.dismiss(); } catch (Throwable ignored) { } popup = null; }
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        int h = MeasureSpec.getSize(hSpec);
        setMeasuredDimension(w, h);
        int pad = dp(14), gap = dp(10);
        int cell = Math.max(0, Math.min((w - 2 * pad - gap) / 2, (h - 2 * pad - gap) / 2));
        int spec = MeasureSpec.makeMeasureSpec(cell, MeasureSpec.EXACTLY);
        for (View t : tiles) t.measure(spec, spec);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        if (tiles.length == 0) return;
        int w = r - l, h = b - t;
        int gap = dp(10);
        int cell = tiles[0].getMeasuredWidth();
        int sx = (w - (2 * cell + gap)) / 2;
        int sy = (h - (2 * cell + gap)) / 2;
        for (int i = 0; i < tiles.length; i++) {
            int x = sx + (i % 2) * (cell + gap);
            int y = sy + (i / 2) * (cell + gap);
            tiles[i].layout(x, y, x + cell, y + cell);
        }
    }
}
