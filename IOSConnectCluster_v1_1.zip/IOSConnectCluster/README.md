# iOS Connect Cluster (LSPosed)
SystemUI me Control Center ki "No playback" media card ki jaga 2x2 cluster: Data, Wi-Fi, Hotspot, Bluetooth.

## Build (GitHub se)
1. Is folder ko naye GitHub repo me push karo (.github/workflows/build.yml saath jaye).
2. Actions tab -> "Build APK" -> artifact `IOSConnectCluster-apk` download.
3. APK install -> LSPosed me enable, scope: System UI -> SystemUI restart (ya reboot).
Agar `de.robv.android.xposed:api:82` download fail ho to XposedBridgeAPI-82.jar `app/libs/` me daal do.

## Debug
LSPosed logs me "IOSConnect:" dhundo. "MediaPlayerPanel mil gaya" aaye to hook lag gaya.

## v1.1
- Look ab stock tiles jaisa: ON = safed gol + neela icon, OFF = grey gol + safed icon (rang `TileView.java` ke upar).
- **Edit button** dabao -> popup: slot chuno, phir tile tap karo. Ek tile do jagah nahi aa sakta (swap ho jata hai).
  Popup me "Stock Edit" se asli editor bhi khulta hai (nichle grid se duplicate tiles hatane ke liye).
- Agar Edit dabane par stock editor hi khule to cluster card par long-press karo (khali jagah).
- Tiles: Data, Wi-Fi, Hotspot, Bluetooth, Torch, Airplane, DND, Silent, Location, Dark.
- Selection `Settings.Secure iosconnect_tiles` me save hoti hai.
